# Tree
Using `numpy`.